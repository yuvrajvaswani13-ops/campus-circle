// Replace these two values with the public Supabase project values.
// NEVER put a service_role key or database password in this file.
window.SUPABASE_URL = "YOUR_SUPABASE_PROJECT_URL";
window.SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
