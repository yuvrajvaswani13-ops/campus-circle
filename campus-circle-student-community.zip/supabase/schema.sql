-- Campus Circle database
-- Run this in Supabase SQL Editor.
-- This schema deliberately starts without direct/private messaging.
-- Keep student profiles minimal and use moderation before publishing.

create extension if not exists pgcrypto;

create table if not exists public.invite_codes (
  id uuid primary key default gen_random_uuid(),
  code_hash text unique not null,
  created_at timestamptz default now(),
  used_at timestamptz,
  used_by uuid
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null,
  display_name text,
  status text not null default 'pending' check (status in ('pending','approved','suspended')),
  is_admin boolean not null default false,
  created_at timestamptz default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  status text not null default 'pending' check (status in ('pending','published','rejected')),
  created_at timestamptz default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  body text not null,
  status text not null default 'pending' check (status in ('pending','published','rejected')),
  created_at timestamptz default now()
);

alter table public.invite_codes enable row level security;
alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;

-- Helper: only approved members can use community content.
create or replace function public.is_approved_member()
returns boolean language sql stable security definer set search_path = public
as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.status='approved'); $$;

-- Secure invite redemption. The browser never reads the invite-code table.
create or replace function public.redeem_invite_code(p_code text)
returns boolean language plpgsql security definer set search_path = public
as $$
declare v_id uuid;
begin
  select id into v_id from public.invite_codes
  where code_hash = encode(digest(p_code, 'sha256'),'hex') and used_at is null
  limit 1 for update;
  if v_id is null then return false; end if;
  update public.invite_codes set used_at=now(), used_by=auth.uid() where id=v_id;
  return true;
end $$;

revoke all on function public.redeem_invite_code(text) from public;
grant execute on function public.redeem_invite_code(text) to authenticated;

create policy "approved members can read approved profiles"
on public.profiles for select to authenticated
using (public.is_approved_member() and status='approved');

create policy "users can create own pending profile"
on public.profiles for insert to authenticated
with check (id=auth.uid() and status='pending' and is_admin=false);

create policy "users can read published posts"
on public.posts for select to authenticated
using (public.is_approved_member() and status='published');

create policy "members can submit posts"
on public.posts for insert to authenticated
with check (public.is_approved_member() and author_id=auth.uid() and status='pending');

create policy "members can read published comments"
on public.comments for select to authenticated
using (public.is_approved_member() and status='published');

create policy "members can submit comments"
on public.comments for insert to authenticated
with check (public.is_approved_member() and author_id=auth.uid() and status='pending');

-- IMPORTANT:
-- Create the first administrator manually in the Supabase dashboard.
-- Then create invite codes by hashing them:
--   select encode(digest('K7F-29Q','sha256'),'hex');
--   insert into public.invite_codes(code_hash) values ('PASTE_HASH_HERE');
-- Never store raw invite codes in client-side JavaScript.
